const slides=[...document.querySelectorAll('.slide')];
let index=0;
const counter=document.getElementById('current');
function show(n){
  index=(n+slides.length)%slides.length;
  slides.forEach((s,i)=>s.classList.toggle('active',i===index));
  counter.textContent=index+1;
  window.scrollTo({top:0,behavior:'smooth'});
}
document.getElementById('next').onclick=()=>show(index+1);
document.getElementById('prev').onclick=()=>show(index-1);
document.addEventListener('keydown',e=>{
  if(e.key==='ArrowRight'||e.key===' '){e.preventDefault();show(index+1)}
  if(e.key==='ArrowLeft'){e.preventDefault();show(index-1)}
});
let startX=0;
document.addEventListener('touchstart',e=>startX=e.touches[0].clientX,{passive:true});
document.addEventListener('touchend',e=>{
  const dx=e.changedTouches[0].clientX-startX;
  if(Math.abs(dx)>50) show(index+(dx<0?1:-1));
},{passive:true});
